/**
 * ============================================================
 * 📱 SICAK PATATES - ÇOKLU CİHAZ YEREL SUNUCUSU (LOCAL SERVER)
 * Bilgisayar, Telefon ve Tabletlerin Aynı Wi-Fi Üzerinden Oynamasını Sağlar
 * ============================================================
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = 3000;

// Yerel Ağ IPv4 Adresini Bul
function getLocalIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        // Genellikle 192.168.x.x veya 10.x.x.x
        if (net.address.startsWith('192.168.') || net.address.startsWith('10.')) {
          return net.address;
        }
      }
    }
  }
  // Alternatif bul
  for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return 'localhost';
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

const server = http.createServer((req, res) => {
  // CORS başlıkları
  res.setHeader('Access-Control-Allow-Origin', '*');

  // Bilgi API'si (Web sayfasının telefon adresini öğrenmesi için)
  if (req.url === '/api/info') {
    const localIp = getLocalIp();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ip: localIp,
      port: PORT,
      mobileUrl: `http://${localIp}:${PORT}`
    }));
    return;
  }

  // Dosya Yolu Belirleme
  let reqPath = req.url.split('?')[0];
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  const filePath = path.join(__dirname, decodeURIComponent(reqPath));

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Bulunamadı');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, { 'Content-Type': contentType });
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const ip = getLocalIp();
  console.log('\n======================================================');
  console.log(' 🔥 SICAK PATATES OYUN SUNUCUSU BAŞLATILDI!');
  console.log('======================================================');
  console.log(` 💻 Bilgisayarda Oyna : http://localhost:${PORT}`);
  console.log(` 📱 Telefonda Oyna    : http://${ip}:${PORT}`);
  console.log('------------------------------------------------------');
  console.log(' 💡 Telefon veya tabletinizin aynı Wi-Fi ağına bağlı');
  console.log('    olduğundan emin olun ve yukarıdaki adresi açın!');
  console.log('======================================================\n');
});
