@echo off
title Sicak Patates Oyun Sunucusu
echo ====================================================
echo       SICAK PATATES OYUN SUNUCUSU BASLATILIYOR
echo ====================================================
echo.
cd /d "%~dp0"
start http://localhost:3000
node server.js
pause
