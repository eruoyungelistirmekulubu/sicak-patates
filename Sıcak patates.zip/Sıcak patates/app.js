/**
 * ============================================================
 * 🔥 SICAK PATATES OYUNU (HOT POTATO) - APP.JS
 * Web Audio API Ses Sentezleyicisi, Partikül Efektleri & Oyun Motoru
 * ============================================================
 */

// --- 1. SES SENTEZLEYİCİSİ (WEB AUDIO API) ---
class SoundController {
  constructor() {
    this.ctx = null;
    this.isMuted = false;
    this.initAudioContext();
  }

  initAudioContext() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) {
      this.ctx = new AudioCtx();
    }
  }

  resumeContext() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  // Tık / Saat Sayacı Sesi
  playTick(frequency = 440) {
    if (this.isMuted || !this.ctx) return;
    this.resumeContext();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(frequency, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(frequency * 0.5, this.ctx.currentTime + 0.06);

    gain.gain.setValueAtTime(0.25, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.06);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.07);
  }

  // Pas / Fırlatma Sesi (Whoosh)
  playPassWhoosh() {
    if (this.isMuted || !this.ctx) return;
    this.resumeContext();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(280, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(650, this.ctx.currentTime + 0.12);

    gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.14);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.15);
  }

  // Cızırtı / Yanma Sesi (Sizzle)
  playSizzle() {
    if (this.isMuted || !this.ctx) return;
    this.resumeContext();

    const bufferSize = this.ctx.sampleRate * 0.1;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(3200, this.ctx.currentTime);
    filter.Q.setValueAtTime(3, this.ctx.currentTime);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.1);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);

    noise.start();
  }

  // Patlama Sesi (BOOM!)
  playExplosion() {
    if (this.isMuted || !this.ctx) return;
    this.resumeContext();

    // 1. Derin Bas Darbesi
    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(25, this.ctx.currentTime + 0.6);

    oscGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
    oscGain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.6);

    osc.connect(oscGain);
    oscGain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.65);

    // 2. Patlama Gürültüsü (Noise Blast)
    const bufferSize = this.ctx.sampleRate * 0.7;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1200, this.ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(100, this.ctx.currentTime + 0.7);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(0.6, this.ctx.currentTime);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.7);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);

    noise.start();
  }

  // Zafer Müziği Melodisi
  playFanfare() {
    if (this.isMuted || !this.ctx) return;
    this.resumeContext();

    const notes = [
      { f: 523.25, d: 0.12, t: 0 },    // C5
      { f: 659.25, d: 0.12, t: 0.13 }, // E5
      { f: 783.99, d: 0.15, t: 0.26 }, // G5
      { f: 1046.50, d: 0.45, t: 0.42 } // C6
    ];

    notes.forEach(n => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(n.f, this.ctx.currentTime + n.t);

      gain.gain.setValueAtTime(0.3, this.ctx.currentTime + n.t);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + n.t + n.d);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(this.ctx.currentTime + n.t);
      osc.stop(this.ctx.currentTime + n.t + n.d + 0.05);
    });
  }
}

// --- 2. PARTİKÜL SİSTEMİ (CANVAS SPARKS & CONFETTI) ---
class ParticleSystem {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.particles = [];
    this.confetti = [];
    this.resize();
    window.addEventListener('resize', () => this.resize());
    this.loop();
  }

  resize() {
    this.width = this.canvas.width = window.innerWidth;
    this.height = this.canvas.height = window.innerHeight;
  }

  addSpark(x, y, count = 3, isIntense = false) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: x || (Math.random() * this.width),
        y: y || (this.height + 10),
        vx: (Math.random() - 0.5) * (isIntense ? 4 : 1.5),
        vy: -(Math.random() * (isIntense ? 5 : 2.5) + 1.5),
        size: Math.random() * 3.5 + 1.5,
        alpha: 1,
        color: isIntense
          ? ['#ff0033', '#ff6600', '#ffcc00'][Math.floor(Math.random() * 3)]
          : ['#ff8800', '#ffaa33', '#ff4400'][Math.floor(Math.random() * 3)],
        decay: Math.random() * 0.02 + 0.008
      });
    }
  }

  addExplosion(x, y) {
    for (let i = 0; i < 70; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 9 + 2;
      this.particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: Math.random() * 5 + 2,
        alpha: 1,
        color: ['#ff1100', '#ff6600', '#ffea00', '#ffffff'][Math.floor(Math.random() * 4)],
        decay: Math.random() * 0.03 + 0.015
      });
    }
  }

  addConfetti() {
    const colors = ['#ff2a6d', '#00e5ff', '#ffbe0b', '#00f5d4', '#7b2cbf', '#ffffff'];
    for (let i = 0; i < 90; i++) {
      this.confetti.push({
        x: this.width * 0.5 + (Math.random() - 0.5) * 100,
        y: this.height * 0.4,
        vx: (Math.random() - 0.5) * 12,
        vy: (Math.random() - 0.7) * 14,
        w: Math.random() * 10 + 6,
        h: Math.random() * 6 + 4,
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 12,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        gravity: 0.22,
        decay: Math.random() * 0.008 + 0.005
      });
    }
  }

  loop() {
    this.ctx.clearRect(0, 0, this.width, this.height);

    // Kıvılcımlar
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= p.decay;

      if (p.alpha <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.globalAlpha = p.alpha;
      this.ctx.fillStyle = p.color;
      this.ctx.beginPath();
      this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }

    // Konfeti
    for (let i = this.confetti.length - 1; i >= 0; i--) {
      const c = this.confetti[i];
      c.x += c.vx;
      c.y += c.vy;
      c.vy += c.gravity;
      c.rotation += c.rotationSpeed;
      c.alpha -= c.decay;

      if (c.alpha <= 0 || c.y > this.height) {
        this.confetti.splice(i, 1);
        continue;
      }

      this.ctx.save();
      this.ctx.globalAlpha = c.alpha;
      this.ctx.translate(c.x, c.y);
      this.ctx.rotate((c.rotation * Math.PI) / 180);
      this.ctx.fillStyle = c.color;
      this.ctx.fillRect(-c.w / 2, -c.h / 2, c.w, c.h);
      this.ctx.restore();
    }

    // Doğal arkaplan kıvılcımı ekle
    if (Math.random() < 0.25) {
      this.addSpark(null, null, 1, false);
    }

    requestAnimationFrame(() => this.loop());
  }
}

// --- 3. EĞLENCELİ PARTİ CEZA GÖREVLERİ (DARE POOL) ---
const FUNNY_DARES = [
  "15 saniye boyunca tavuk gibi gıdaklayıp kanat çırp!",
  "Odada bulunan rastgele bir eşyaya (örneğin sandalyeye) aşk ilanı yap!",
  "En sevdiğin şarkının nakaratını opera sanatçısı gibi söyle!",
  "Sıradaki tur boyunca sadece fısıldayarak konuş!",
  "Gruptaki birinin en komik özelliğini taklit et!",
  "10 saniye boyunca robot dansı yap!",
  "Aynaya bak ve kendine 3 tane aşırı abartılı iltifat et!",
  "En utanç verici veya en komik okul anını anlat!",
  "Kurt gibi gökyüzüne doğru 5 saniye boyunca ulu!",
  "Gruptakilerin seçeceği bir hayvanın sesini kusursuz çıkar!",
  "Hiç gülmeden gruptaki herkesin gözlerinin içine 3'er saniye bak!",
  "Gruptan birine komik bir lakap tak ve gerekçesini açıkla!",
  "Son çektiğin fotoğrafı (özel değilse) herkese göster!",
  "Bir spiker gibi son turdaki elenmeni abartılı bir dille anlat!",
  "Dilini burnuna değdirmeye çalışırken fotoğraf çektir!",
  "En iyi film kahramanı taklidini yap!"
];

// Varsayılan Oyuncu İsimleri ve Emojileri
const DEFAULT_AVATARS = ['😎', '🤠', '🥷', '👽', '🦄', '🦁', '🦊', '🐼'];
const DEFAULT_NAMES = ['Kıvılcım', 'Şimşek', 'Ateşbaz', 'Patato', 'BombaCan', 'Kızartma', 'Roket', 'Panik'];

// --- 4. OYUN ANA DURUMU VE KONTROLCÜSÜ ---
class HotPotatoGame {
  constructor() {
    this.sound = new SoundController();
    this.particles = new ParticleSystem(document.getElementById('particleCanvas'));

    // Ayarlar & Durum
    this.playerCount = 4;
    this.players = [];
    this.alivePlayerIndices = [];
    this.currentHolderIndex = 0;
    this.roundNumber = 1;
    this.roundDuration = 0; // ms
    this.roundStartTime = 0;
    this.isRoundRunning = false;
    this.roundTimerId = null;
    this.tickIntervalId = null;
    this.botPassTimeoutId = null;

    // Parti Modu Durumu
    this.isPartyModeRunning = false;
    this.partyTimerId = null;
    this.partyTickId = null;
    // 100 Soru Modu Durumu
    this.isQuestionsEnabled = true;
    this.selectedCategory = 'all';
    this.activeQuestion = null;
    this.usedQuestionIds = new Set();

    // Parti Modu Süre Seçimi (Varsayılan: 45-85 sn, 30 Kişilik Dev Parti desteği)
    this.partyMinTime = 45;
    this.partyMaxTime = 85;
    this.partyPassCount = 1;

    this.cacheElements();
    this.bindEvents();
    this.initPlayerSetupInputs();
  }

  cacheElements() {
    // Görünümler
    this.mainMenu = document.getElementById('mainMenu');
    this.setupView = document.getElementById('setupView');
    this.arcadeGameView = document.getElementById('arcadeGameView');
    this.partyModeView = document.getElementById('partyModeView');

    // Modallar
    this.rulesModal = document.getElementById('rulesModal');
    this.eliminationModal = document.getElementById('eliminationModal');
    this.winnerModal = document.getElementById('winnerModal');

    // Butonlar
    this.selectArcadeModeBtn = document.getElementById('selectArcadeMode');
    this.selectPartyModeBtn = document.getElementById('selectPartyMode');
    this.setupBackBtn = document.getElementById('setupBackBtn');
    this.partyBackBtn = document.getElementById('partyBackBtn');
    this.rulesBtn = document.getElementById('rulesBtn');
    this.closeRulesBtn = document.getElementById('closeRulesBtn');
    this.rulesOkBtn = document.getElementById('rulesOkBtn');
    this.soundToggleBtn = document.getElementById('soundToggleBtn');
    this.soundIconOn = document.getElementById('soundIconOn');
    this.soundIconOff = document.getElementById('soundIconOff');

    this.startArcadeGameBtn = document.getElementById('startArcadeGameBtn');
    this.randomizeNamesBtn = document.getElementById('randomizeNamesBtn');
    this.passPotatoBtn = document.getElementById('passPotatoBtn');
    this.continueArcadeBtn = document.getElementById('continueArcadeBtn');
    this.playAgainBtn = document.getElementById('playAgainBtn');
    this.returnMenuBtn = document.getElementById('returnMenuBtn');
    this.arcadeBackBtn = document.getElementById('arcadeBackBtn');
    this.eliminationMenuBtn = document.getElementById('eliminationMenuBtn');

    // Arcade Alanı
    this.arenaCircle = document.getElementById('arenaCircle');
    this.hotPotatoEl = document.getElementById('hotPotatoEl');
    this.activePotatoSvg = document.getElementById('activePotatoSvg');
    this.sweatDrop = document.getElementById('sweatDrop');
    this.tensionBar = document.getElementById('tensionBar');
    this.roundCounter = document.getElementById('roundCounter');
    this.aliveCounter = document.getElementById('aliveCounter');
    this.currentTurnName = document.getElementById('currentTurnName');
    this.turnActionHint = document.getElementById('turnActionHint');

    // Formlar
    this.playerInputsList = document.getElementById('playerInputsList');
    this.botFillCheckbox = document.getElementById('botFillCheckbox');
    this.daresCheckbox = document.getElementById('daresCheckbox');

    // Parti Modu Elemanları
    this.startPartyRoundBtn = document.getElementById('startPartyRoundBtn');
    this.passPartyDeviceBtn = document.getElementById('passPartyDeviceBtn');
    this.partyStatusText = document.getElementById('partyStatusText');
    this.partyDareCard = document.getElementById('partyDareCard');
    this.partyDareText = document.getElementById('partyDareText');
    this.nextPartyRoundBtn = document.getElementById('nextPartyRoundBtn');
    this.partyPotatoAnim = document.getElementById('partyPotatoAnim');
    this.partyHeatHalo = document.getElementById('partyHeatHalo');
    this.partyTimeSelector = document.getElementById('partyTimeSelector');
    this.partyPassCounterBox = document.getElementById('partyPassCounterBox');
    this.partyPassCountDisplay = document.getElementById('partyPassCountDisplay');
    this.partyDareHeadline = document.getElementById('partyDareHeadline');
    this.partyInstructions = document.getElementById('partyInstructions');

    // Soru Sistemi Elemanları
    this.questionsEnabledCheckbox = document.getElementById('questionsEnabledCheckbox');
    this.questionCategoryPickerGroup = document.getElementById('questionCategoryPickerGroup');
    this.arcadeQuestionCard = document.getElementById('arcadeQuestionCard');
    this.arcadeQuestionCatBadge = document.getElementById('arcadeQuestionCatBadge');
    this.arcadeQuestionText = document.getElementById('arcadeQuestionText');
    this.partyQuestionCard = document.getElementById('partyQuestionCard');
    this.partyQuestionCatBadge = document.getElementById('partyQuestionCatBadge');
    this.partyQuestionText = document.getElementById('partyQuestionText');

    // 100 Soru Listesi Modalı
    this.allQuestionsModal = document.getElementById('allQuestionsModal');
    this.viewQuestionsBtn = document.getElementById('viewQuestionsBtn');
    this.closeQuestionsModalBtn = document.getElementById('closeQuestionsModalBtn');
    this.closeQuestionsOkBtn = document.getElementById('closeQuestionsOkBtn');
    this.questionsScrollList = document.getElementById('questionsScrollList');

    // Mobil & Çoklu Cihaz Elemanları
    this.phoneQrBtn = document.getElementById('phoneQrBtn');
    this.fullscreenBtn = document.getElementById('fullscreenBtn');
    this.fullscreenIconExpand = document.getElementById('fullscreenIconExpand');
    this.fullscreenIconCompress = document.getElementById('fullscreenIconCompress');
    this.phoneQrModal = document.getElementById('phoneQrModal');
    this.closePhoneQrBtn = document.getElementById('closePhoneQrBtn');
    this.phoneQrOkBtn = document.getElementById('phoneQrOkBtn');
    this.copyUrlBtn = document.getElementById('copyUrlBtn');
    this.mobileNetworkInput = document.getElementById('mobileNetworkInput');
    this.qrCodeCanvas = document.getElementById('qrCodeCanvas');
  }

  bindEvents() {
    // Mobil Dokunma & Ses Kilidini Aç
    this.setupMobileFeatures();

    // Tam Ekran Düğmesi ve Değişim Takibi
    if (this.fullscreenBtn) {
      this.fullscreenBtn.addEventListener('click', () => this.toggleFullscreen());
    }
    document.addEventListener('fullscreenchange', () => this.updateFullscreenUI());
    document.addEventListener('webkitfullscreenchange', () => this.updateFullscreenUI());

    // Telefon QR Modalı
    if (this.phoneQrBtn) {
      this.phoneQrBtn.addEventListener('click', () => this.openPhoneQrModal());
    }
    if (this.closePhoneQrBtn) {
      this.closePhoneQrBtn.addEventListener('click', () => this.phoneQrModal.classList.add('hidden'));
    }
    if (this.phoneQrOkBtn) {
      this.phoneQrOkBtn.addEventListener('click', () => this.phoneQrModal.classList.add('hidden'));
    }
    if (this.copyUrlBtn) {
      this.copyUrlBtn.addEventListener('click', () => {
        if (this.mobileNetworkInput) {
          navigator.clipboard.writeText(this.mobileNetworkInput.value).then(() => {
            const original = this.copyUrlBtn.textContent;
            this.copyUrlBtn.textContent = 'Kopyalandı! ✔';
            setTimeout(() => { this.copyUrlBtn.textContent = original; }, 2000);
          }).catch(() => {
            this.mobileNetworkInput.select();
            document.execCommand('copy');
          });
        }
      });
    }

    // Ses Kontrolü
    this.soundToggleBtn.addEventListener('click', () => {
      const isMuted = this.sound.toggleMute();
      this.soundIconOn.classList.toggle('hidden', isMuted);
      this.soundIconOff.classList.toggle('hidden', !isMuted);
    });

    // 100 Soru Kütüphanesi Modalı
    if (this.viewQuestionsBtn) {
      this.viewQuestionsBtn.addEventListener('click', () => {
        this.renderQuestionsModalList('all');
        this.allQuestionsModal.classList.remove('hidden');
      });
    }
    if (this.closeQuestionsModalBtn) {
      this.closeQuestionsModalBtn.addEventListener('click', () => {
        this.allQuestionsModal.classList.add('hidden');
      });
    }
    if (this.closeQuestionsOkBtn) {
      this.closeQuestionsOkBtn.addEventListener('click', () => {
        this.allQuestionsModal.classList.add('hidden');
      });
    }

    // Modal İçi Kategori Filtreleri
    document.querySelectorAll('.q-filter-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.q-filter-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.renderQuestionsModalList(e.target.dataset.filter);
      });
    });

    // Kurulum Ekranındaki Kategori Hapları
    document.querySelectorAll('.cat-pill').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.cat-pill').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.selectedCategory = e.target.dataset.cat;
      });
    });

    // Soru Modu Aç/Kapa
    if (this.questionsEnabledCheckbox) {
      this.questionsEnabledCheckbox.addEventListener('change', (e) => {
        this.isQuestionsEnabled = e.target.checked;
        if (this.questionCategoryPickerGroup) {
          this.questionCategoryPickerGroup.style.display = this.isQuestionsEnabled ? 'block' : 'none';
        }
      });
    }

    // Kurallar Modalı
    this.rulesBtn.addEventListener('click', () => this.rulesModal.classList.remove('hidden'));
    this.closeRulesBtn.addEventListener('click', () => this.rulesModal.classList.add('hidden'));
    this.rulesOkBtn.addEventListener('click', () => this.rulesModal.classList.add('hidden'));

    // Menü Yönlendirmeleri
    this.selectArcadeModeBtn.addEventListener('click', () => this.switchView(this.setupView));
    this.setupBackBtn.addEventListener('click', () => this.switchView(this.mainMenu));
    this.selectPartyModeBtn.addEventListener('click', () => {
      if (this.partyInstructions) this.partyInstructions.classList.remove('hidden');
      this.switchView(this.partyModeView);
    });
    this.partyBackBtn.addEventListener('click', () => {
      this.stopPartyRound();
      this.switchView(this.mainMenu);
    });

    // Oyuncu Sayısı Seçimi
    document.querySelectorAll('.count-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.count-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.playerCount = parseInt(e.target.dataset.count);
        this.initPlayerSetupInputs();
      });
    });

    // Rastgele İsimler
    this.randomizeNamesBtn.addEventListener('click', () => this.randomizeNames());

    // Oyunu Başlat (Arcade)
    this.startArcadeGameBtn.addEventListener('click', () => this.startArcadeGame());

    // Patatesi Pasla (Buton & Boşluk Tuşu)
    this.passPotatoBtn.addEventListener('click', () => this.handlePlayerPass());
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space' && this.isRoundRunning && this.arcadeGameView.classList.contains('active-view')) {
        e.preventDefault();
        this.handlePlayerPass();
      }
    });

    // Pencere yeniden boyutlandırıldığında çemberi güncelle
    window.addEventListener('resize', () => {
      if (this.arcadeGameView.classList.contains('active-view') && this.players.length > 0) {
        this.renderArenaCircle();
      }
    });

    // Modallardaki Devam Butonları
    this.continueArcadeBtn.addEventListener('click', () => {
      this.eliminationModal.classList.add('hidden');
      this.startArcadeRound();
    });

    if (this.eliminationMenuBtn) {
      this.eliminationMenuBtn.addEventListener('click', () => this.quitArcadeToMenu());
    }

    if (this.arcadeBackBtn) {
      this.arcadeBackBtn.addEventListener('click', () => this.quitArcadeToMenu());
    }

    this.playAgainBtn.addEventListener('click', () => {
      this.winnerModal.classList.add('hidden');
      this.startArcadeGame();
    });

    this.returnMenuBtn.addEventListener('click', () => {
      this.winnerModal.classList.add('hidden');
      this.switchView(this.mainMenu);
    });

    // Parti Modu Butonları
    this.startPartyRoundBtn.addEventListener('click', () => this.startPartyRound());
    this.passPartyDeviceBtn.addEventListener('click', () => {
      this.partyPassCount++;
      if (this.partyPassCountDisplay) {
        this.partyPassCountDisplay.textContent = this.partyPassCount;
      }
      if (this.partyPassCounterBox) {
        this.partyPassCounterBox.classList.remove('pop-anim');
        void this.partyPassCounterBox.offsetWidth;
        this.partyPassCounterBox.classList.add('pop-anim');
      }

      this.sound.playPassWhoosh();
      if (navigator.vibrate) {
        try { navigator.vibrate(35); } catch (e) {}
      }
      this.drawNextQuestion();
      this.particles.addSpark(window.innerWidth / 2, window.innerHeight / 2, 8, true);
    });
    this.nextPartyRoundBtn.addEventListener('click', () => this.startPartyRound());

    // Parti Süre Seçici Düğmeleri
    document.querySelectorAll('.party-time-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.party-time-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.partyMinTime = parseInt(e.target.dataset.min);
        this.partyMaxTime = parseInt(e.target.dataset.max);
      });
    });
  }

  switchView(targetView) {
    [this.mainMenu, this.setupView, this.arcadeGameView, this.partyModeView].forEach(v => {
      v.classList.remove('active-view');
    });
    targetView.classList.add('active-view');
  }

  // --- OYUNCU KURULUMU ---
  initPlayerSetupInputs() {
    this.playerInputsList.innerHTML = '';
    for (let i = 0; i < this.playerCount; i++) {
      const avatar = DEFAULT_AVATARS[i % DEFAULT_AVATARS.length];
      const name = DEFAULT_NAMES[i % DEFAULT_NAMES.length];

      const row = document.createElement('div');
      row.className = 'player-input-row';
      row.innerHTML = `
        <span class="player-avatar-emoji">${avatar}</span>
        <input type="text" class="player-name-field" data-index="${i}" value="${name}" maxlength="14" placeholder="Oyuncu ${i + 1}">
      `;
      this.playerInputsList.appendChild(row);
    }
  }

  randomizeNames() {
    const shuffledNames = [...DEFAULT_NAMES].sort(() => Math.random() - 0.5);
    const inputs = this.playerInputsList.querySelectorAll('.player-name-field');
    inputs.forEach((input, idx) => {
      input.value = shuffledNames[idx % shuffledNames.length];
    });
  }

  // --- ARCADE MODU BAŞLATMA ---
  startArcadeGame() {
    // Oyuncuları Topla
    const inputs = this.playerInputsList.querySelectorAll('.player-name-field');
    const isBotFill = this.botFillCheckbox.checked;

    this.players = [];
    inputs.forEach((inp, i) => {
      const name = inp.value.trim() || `Oyuncu ${i + 1}`;
      const avatar = DEFAULT_AVATARS[i % DEFAULT_AVATARS.length];
      // İlk oyuncu insan, bot fill aktifse diğerleri bot olabilir
      const isBot = isBotFill ? (i !== 0) : false;

      this.players.push({
        id: i,
        name: name,
        avatar: avatar,
        isBot: isBot,
        isAlive: true
      });
    });

    this.alivePlayerIndices = this.players.map((_, i) => i);
    this.roundNumber = 1;
    this.currentHolderIndex = Math.floor(Math.random() * this.players.length);

    this.switchView(this.arcadeGameView);
    this.renderArenaCircle();
    this.startArcadeRound();
  }

  // Arcade Modundan Ana Menüye Çıkış
  quitArcadeToMenu() {
    this.isRoundRunning = false;
    clearTimeout(this.roundTimerId);
    clearInterval(this.tickIntervalId);
    clearTimeout(this.botPassTimeoutId);
    this.resetPotatoVisuals();
    if (this.eliminationModal) this.eliminationModal.classList.add('hidden');
    this.switchView(this.mainMenu);
  }

  // Çemberdeki Oyuncu Düğümlerini Çiz
  renderArenaCircle() {
    this.arenaCircle.innerHTML = '';
    const total = this.players.length;
    const isMobile = window.innerWidth <= 600;
    const circleW = this.arenaCircle.offsetWidth || (isMobile ? 290 : 360);
    const circleH = this.arenaCircle.offsetHeight || circleW;
    const radius = Math.max(68, Math.min(circleW, circleH) / 2 - (isMobile ? 20 : 25));

    this.players.forEach((player, i) => {
      // Trigonometrik yerleşim (Açı: -90 dereceden başlar, tepe noktası)
      const angle = ((i / total) * 2 * Math.PI) - (Math.PI / 2);
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;

      const node = document.createElement('div');
      node.className = `player-node ${!player.isAlive ? 'eliminated' : ''} ${i === this.currentHolderIndex ? 'active-holder' : ''}`;
      node.id = `playerNode-${i}`;
      node.style.transform = `translate(${x}px, ${y}px)`;

      node.innerHTML = `
        <div class="player-avatar-circle">
          <span>${player.avatar}</span>
        </div>
        <span class="player-name-tag">${player.name}${player.isBot ? ' 🤖' : ''}</span>
      `;

      // Tıklayarak pas atma desteği
      node.addEventListener('click', () => {
        if (this.isRoundRunning && !this.getCurrentHolder().isBot && player.isAlive && i !== this.currentHolderIndex) {
          this.passPotatoTo(i);
        }
      });

      this.arenaCircle.appendChild(node);
    });

    this.updateHud();
  }

  updateHud() {
    this.roundCounter.textContent = this.roundNumber;
    this.aliveCounter.textContent = `${this.alivePlayerIndices.length}/${this.players.length}`;
    
    const holder = this.getCurrentHolder();
    if (holder) {
      this.currentTurnName.textContent = `${holder.avatar} ${holder.name}`;
      if (holder.isBot) {
        this.turnActionHint.textContent = '(Bot düşünüyor...)';
        this.passPotatoBtn.disabled = true;
        this.passPotatoBtn.style.opacity = '0.5';
      } else {
        this.turnActionHint.textContent = '(Hemen Boşluk tuşuna bas veya tıkla!)';
        this.passPotatoBtn.disabled = false;
        this.passPotatoBtn.style.opacity = '1';
      }
    }
  }

  getCurrentHolder() {
    return this.players[this.currentHolderIndex];
  }

  // Yeni Tur Başlat
  startArcadeRound() {
    this.isRoundRunning = true;
    this.resetPotatoVisuals();
    this.drawNextQuestion();

    // Rastgele süre: 12 ile 26 saniye arası
    this.roundDuration = (Math.floor(Math.random() * 14) + 12) * 1000;
    this.roundStartTime = Date.now();

    // Zamanlayıcıları temizle
    clearTimeout(this.roundTimerId);
    clearInterval(this.tickIntervalId);
    clearTimeout(this.botPassTimeoutId);

    // Patlama Tetikleyicisi
    this.roundTimerId = setTimeout(() => {
      this.triggerExplosion();
    }, this.roundDuration);

    // Dinamik Tık ve Isınma Döngüsü
    this.runRoundTickLoop();

    // Eğer patates botun elindeyse bot pas atsın
    this.checkBotTurn();
  }

  runRoundTickLoop() {
    const updateTick = () => {
      if (!this.isRoundRunning) return;

      const elapsed = Date.now() - this.roundStartTime;
      const progress = Math.min(elapsed / this.roundDuration, 1);

      // Sıcaklık Barı
      this.tensionBar.style.width = `${progress * 100}%`;

      // Isı ve Gerginlik Seviyeleri (1, 2, 3)
      if (progress < 0.45) {
        this.setPotatoHeatStage(1);
        this.sound.playTick(420);
      } else if (progress < 0.8) {
        this.setPotatoHeatStage(2);
        this.sound.playTick(580);
        if (Math.random() < 0.3) this.sound.playSizzle();
      } else {
        this.setPotatoHeatStage(3);
        this.sound.playTick(780);
        this.sound.playSizzle();
        // Kıvılcım saç
        const rect = this.hotPotatoEl.getBoundingClientRect();
        this.particles.addSpark(rect.left + rect.width / 2, rect.top + rect.height / 2, 3, true);
      }

      // Süre yaklaştıkça tık aralığı 800ms'den 120ms'ye kadar hızlanır
      const nextDelay = Math.max(120, 800 * (1 - progress * 0.85));
      this.tickIntervalId = setTimeout(updateTick, nextDelay);
    };

    updateTick();
  }

  setPotatoHeatStage(stage) {
    this.hotPotatoEl.classList.remove('heat-stage-1', 'heat-stage-2', 'heat-stage-3');
    this.sweatDrop.classList.remove('sweat-visible');

    if (stage === 1) {
      this.hotPotatoEl.classList.add('heat-stage-1');
    } else if (stage === 2) {
      this.hotPotatoEl.classList.add('heat-stage-2');
      this.sweatDrop.classList.add('sweat-visible');
    } else if (stage === 3) {
      this.hotPotatoEl.classList.add('heat-stage-3');
      this.sweatDrop.classList.add('sweat-visible');
    }
  }

  resetPotatoVisuals() {
    this.hotPotatoEl.classList.remove('heat-stage-1', 'heat-stage-2', 'heat-stage-3');
    this.sweatDrop.classList.remove('sweat-visible');
    this.tensionBar.style.width = '5%';
  }

  // Pas Verme İşlemi
  handlePlayerPass() {
    if (!this.isRoundRunning) return;
    const holder = this.getCurrentHolder();
    if (holder && holder.isBot) return; // Bot sırasında insan tıklayamaz

    this.passToNextPlayer();
  }

  passToNextPlayer() {
    if (!this.isRoundRunning) return;

    // Yaşayan sonraki oyuncuyu bul
    const currentPosInAlive = this.alivePlayerIndices.indexOf(this.currentHolderIndex);
    const nextPosInAlive = (currentPosInAlive + 1) % this.alivePlayerIndices.length;
    const nextHolderIndex = this.alivePlayerIndices[nextPosInAlive];

    this.passPotatoTo(nextHolderIndex);
  }

  passPotatoTo(targetIndex) {
    if (!this.isRoundRunning) return;

    this.sound.playPassWhoosh();

    // Eski holder stilini kaldır
    const oldNode = document.getElementById(`playerNode-${this.currentHolderIndex}`);
    if (oldNode) oldNode.classList.remove('active-holder');

    // Patates zıplama animasyonu
    this.hotPotatoEl.style.transform = 'scale(0.8) rotate(15deg)';
    setTimeout(() => {
      this.hotPotatoEl.style.transform = 'scale(1) rotate(0deg)';
    }, 150);

    // Yeni holder ata
    this.currentHolderIndex = targetIndex;
    const newNode = document.getElementById(`playerNode-${this.currentHolderIndex}`);
    if (newNode) newNode.classList.add('active-holder');

    // Mobil Titreşim
    if (navigator.vibrate) {
      try { navigator.vibrate(35); } catch (e) {}
    }

    // Kıvılcım
    const rect = this.hotPotatoEl.getBoundingClientRect();
    this.particles.addSpark(rect.left + rect.width / 2, rect.top + rect.height / 2, 4, false);

    // Yeni Oyuncu İçin Yeni Soru Çek
    this.drawNextQuestion();

    this.updateHud();
    this.checkBotTurn();
  }

  checkBotTurn() {
    clearTimeout(this.botPassTimeoutId);
    if (!this.isRoundRunning) return;

    const holder = this.getCurrentHolder();
    if (holder && holder.isBot) {
      // Bot tepki süresi (gerginliğe göre 400ms ile 1200ms arası)
      const elapsed = Date.now() - this.roundStartTime;
      const progress = Math.min(elapsed / this.roundDuration, 1);
      const delay = Math.floor(Math.random() * (700 - progress * 300)) + 350;

      this.botPassTimeoutId = setTimeout(() => {
        if (this.isRoundRunning) {
          this.passToNextPlayer();
        }
      }, delay);
    }
  }

  // --- PATLAMA ANI (BOOM!) ---
  triggerExplosion() {
    this.isRoundRunning = false;
    clearTimeout(this.roundTimerId);
    clearTimeout(this.tickIntervalId);
    clearTimeout(this.botPassTimeoutId);

    // Ses ve Efektler
    this.sound.playExplosion();
    document.body.classList.add('screen-quake');
    setTimeout(() => document.body.classList.remove('screen-quake'), 650);

    // Mobil Titreşim
    if (navigator.vibrate) {
      try { navigator.vibrate([150, 70, 250, 70, 450]); } catch (e) {}
    }

    const rect = this.hotPotatoEl.getBoundingClientRect();
    this.particles.addExplosion(rect.left + rect.width / 2, rect.top + rect.height / 2);

    // Elenen Oyuncu
    const eliminatedPlayer = this.getCurrentHolder();
    eliminatedPlayer.isAlive = false;

    // Yaşayanlar listesinden çıkar
    this.alivePlayerIndices = this.alivePlayerIndices.filter(idx => idx !== this.currentHolderIndex);

    // Oyuncu düğümünü işaretle
    const node = document.getElementById(`playerNode-${this.currentHolderIndex}`);
    if (node) {
      node.classList.remove('active-holder');
      node.classList.add('eliminated');
    }

    // Oyun bitti mi? (Sadece 1 kişi mi kaldı?)
    if (this.alivePlayerIndices.length <= 1) {
      setTimeout(() => {
        this.triggerWinnerCeremony();
      }, 1200);
      return;
    }

    // Sıradaki tura geçiş için yeni holder belirle
    this.currentHolderIndex = this.alivePlayerIndices[0];
    const nextNode = document.getElementById(`playerNode-${this.currentHolderIndex}`);
    if (nextNode) nextNode.classList.add('active-holder');

    this.roundNumber++;

    // Ceza ve Elenme Modalını Aç
    setTimeout(() => {
      this.showEliminationModal(eliminatedPlayer);
    }, 800);
  }

  showEliminationModal(eliminatedPlayer) {
    document.getElementById('eliminatedPlayerTitle').textContent = `${eliminatedPlayer.avatar} ${eliminatedPlayer.name} Elendi!`;

    const dareSection = document.getElementById('dareSection');
    const modalDareText = document.getElementById('modalDareText');

    if (this.daresCheckbox.checked) {
      dareSection.classList.remove('hidden');
      const randomDare = FUNNY_DARES[Math.floor(Math.random() * FUNNY_DARES.length)];
      modalDareText.textContent = `"${randomDare}"`;
    } else {
      dareSection.classList.add('hidden');
    }

    this.eliminationModal.classList.remove('hidden');
  }

  // --- KAZANAN TÖRENİ ---
  triggerWinnerCeremony() {
    const winnerIndex = this.alivePlayerIndices[0];
    const winner = this.players[winnerIndex];

    this.sound.playFanfare();
    this.particles.addConfetti();

    document.getElementById('winnerAvatar').textContent = winner.avatar;
    document.getElementById('winnerPlayerName').textContent = winner.name;

    this.winnerModal.classList.remove('hidden');
  }

  // ============================================================
  // PARTİ MODU (CİHAZI ELDEN ELE GEÇİR)
  // ============================================================
  startPartyRound() {
    this.isPartyModeRunning = true;
    this.partyDareCard.classList.add('hidden');
    if (this.partyInstructions) this.partyInstructions.classList.add('hidden');
    this.startPartyRoundBtn.classList.add('hidden');
    this.passPartyDeviceBtn.classList.remove('hidden');
    this.partyStatusText.textContent = 'PATATES YANIYOR! 🔥';
    this.partyStatusText.style.color = '#ff9d00';

    this.drawNextQuestion();

    // Süre seçiciyi tur sırasında gizle
    if (this.partyTimeSelector) this.partyTimeSelector.style.display = 'none';

    // Seçilen süre aralığında rastgele süre (Varsayılan 35 - 70 saniye)
    const span = Math.max(5, this.partyMaxTime - this.partyMinTime);
    const randomizedSeconds = Math.floor(Math.random() * (span + 1)) + this.partyMinTime;
    this.partyDuration = randomizedSeconds * 1000;
    this.partyStartTime = Date.now();

    // 30 Kişiye Kadar Canlı Pas Sayacını Başlat
    this.partyPassCount = 1;
    if (this.partyPassCountDisplay) this.partyPassCountDisplay.textContent = '1';
    if (this.partyPassCounterBox) this.partyPassCounterBox.classList.remove('hidden');

    clearTimeout(this.partyTimerId);
    clearInterval(this.partyTickId);

    // Titreme sınıfı ekle
    this.partyPotatoAnim.classList.add('heat-stage-1');

    this.partyTimerId = setTimeout(() => {
      this.triggerPartyExplosion();
    }, this.partyDuration);

    this.runPartyTickLoop();
  }

  runPartyTickLoop() {
    const tick = () => {
      if (!this.isPartyModeRunning) return;

      const elapsed = Date.now() - this.partyStartTime;
      const progress = Math.min(elapsed / this.partyDuration, 1);

      if (progress < 0.5) {
        this.partyPotatoAnim.className = 'party-potato-graphic heat-stage-1';
        this.sound.playTick(440);
      } else if (progress < 0.8) {
        this.partyPotatoAnim.className = 'party-potato-graphic heat-stage-2';
        this.sound.playTick(600);
        this.partyStatusText.textContent = 'ÇOK SICAK! HIZLAN! ⚠️';
        this.partyStatusText.style.color = '#ff5722';
      } else {
        this.partyPotatoAnim.className = 'party-potato-graphic heat-stage-3';
        this.sound.playTick(820);
        this.sound.playSizzle();
        this.partyStatusText.textContent = 'HER AN PATLAYABİLİR! 💣';
        this.partyStatusText.style.color = '#ff1744';
      }

      const nextDelay = Math.max(120, 800 * (1 - progress * 0.85));
      this.partyTickId = setTimeout(tick, nextDelay);
    };

    tick();
  }

  triggerPartyExplosion() {
    this.isPartyModeRunning = false;
    clearTimeout(this.partyTimerId);
    clearTimeout(this.partyTickId);

    this.sound.playExplosion();

    // Vibrate desteği (mobil cihazlar için)
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 400]);
    }

    document.body.classList.add('screen-quake');
    setTimeout(() => document.body.classList.remove('screen-quake'), 650);

    const rect = this.partyPotatoAnim.getBoundingClientRect();
    this.particles.addExplosion(rect.left + rect.width / 2, rect.top + rect.height / 2);

    this.partyPotatoAnim.className = 'party-potato-graphic';
    this.partyStatusText.textContent = '💥 GÜÜÜÜM! PATLADI!';
    this.partyStatusText.style.color = '#ff1744';

    this.passPartyDeviceBtn.classList.add('hidden');
    this.startPartyRoundBtn.classList.remove('hidden');
    if (this.partyTimeSelector) this.partyTimeSelector.style.display = 'block';
    if (this.partyPassCounterBox) this.partyPassCounterBox.classList.add('hidden');
    if (this.partyInstructions) this.partyInstructions.classList.remove('hidden');

    // 30 Kişilik grupta kaçıncı kişide patladığını duyur
    if (this.partyDareHeadline) {
      this.partyDareHeadline.textContent = `💥 ${this.partyPassCount}. OYUNCUDA PATLADI!`;
    }

    // Ceza Görevi Göster
    const randomDare = FUNNY_DARES[Math.floor(Math.random() * FUNNY_DARES.length)];
    this.partyDareText.textContent = `"${randomDare}"`;
    this.partyDareCard.classList.remove('hidden');
  }

  stopPartyRound() {
    this.isPartyModeRunning = false;
    clearTimeout(this.partyTimerId);
    clearTimeout(this.partyTickId);
    this.partyPotatoAnim.className = 'party-potato-graphic';
    this.partyStatusText.textContent = 'HAZIR';
    this.partyStatusText.style.color = '#ffaa00';
    this.partyDareCard.classList.add('hidden');
    this.passPartyDeviceBtn.classList.add('hidden');
    this.startPartyRoundBtn.classList.remove('hidden');
    if (this.partyTimeSelector) this.partyTimeSelector.style.display = 'block';
    if (this.partyPassCounterBox) this.partyPassCounterBox.classList.add('hidden');
    if (this.partyInstructions) this.partyInstructions.classList.remove('hidden');
  }

  // --- 100 SORU YÖNETİMİ ---
  drawNextQuestion() {
    if (typeof QUESTIONS_DATA === 'undefined' || !this.isQuestionsEnabled) {
      if (this.arcadeQuestionCard) this.arcadeQuestionCard.style.display = 'none';
      if (this.partyQuestionCard) this.partyQuestionCard.style.display = 'none';
      return null;
    }

    if (this.arcadeQuestionCard) this.arcadeQuestionCard.style.display = 'block';
    if (this.partyQuestionCard) this.partyQuestionCard.style.display = 'block';

    let pool = QUESTIONS_DATA;
    if (this.selectedCategory !== 'all') {
      pool = QUESTIONS_DATA.filter(q => q.category === this.selectedCategory);
    }

    if (!pool || pool.length === 0) pool = QUESTIONS_DATA;

    // Aynı oturumda soru tekrarını engelle
    let available = pool.filter(q => !this.usedQuestionIds.has(q.id));
    if (available.length === 0) {
      this.usedQuestionIds.clear();
      available = pool;
    }

    const question = available[Math.floor(Math.random() * available.length)];
    this.usedQuestionIds.add(question.id);
    this.activeQuestion = question;

    // Arcade Soru Kartı Güncelle
    if (this.arcadeQuestionCard && this.arcadeQuestionText) {
      this.arcadeQuestionCatBadge.textContent = question.categoryTitle;
      this.arcadeQuestionText.textContent = question.text;

      // Pop animasyonu
      this.arcadeQuestionCard.classList.remove('pop-anim');
      void this.arcadeQuestionCard.offsetWidth; // Reflow
      this.arcadeQuestionCard.classList.add('pop-anim');
    }

    // Parti Modu Soru Kartı Güncelle
    if (this.partyQuestionCard && this.partyQuestionText) {
      this.partyQuestionCatBadge.textContent = question.categoryTitle;
      this.partyQuestionText.textContent = question.text;
    }

    return question;
  }

  // 100 Soru Listesi Modalı Oluştur
  renderQuestionsModalList(filterCategory = 'all') {
    if (typeof QUESTIONS_DATA === 'undefined' || !this.questionsScrollList) return;
    this.questionsScrollList.innerHTML = '';

    const list = filterCategory === 'all'
      ? QUESTIONS_DATA
      : QUESTIONS_DATA.filter(q => q.category === filterCategory);

    list.forEach(q => {
      const item = document.createElement('div');
      item.className = 'q-item-card';
      item.innerHTML = `
        <span class="q-item-num">#${q.id}</span>
        <div class="q-item-content">
          <div style="font-size: 0.72rem; color: #ffaa00; font-weight: 700; margin-bottom: 2px;">${q.categoryTitle}</div>
          <div class="q-item-text">${q.text}</div>
        </div>
      `;
      this.questionsScrollList.appendChild(item);
    });
  }

  // --- MOBİL & ÇOKLU CİHAZ UYUMLULUK METOTLARI ---
  setupMobileFeatures() {
    // iOS Safari ve Android için Ses Kilidini Aç
    const unlock = () => {
      if (this.sound && this.sound.ctx) {
        if (this.sound.ctx.state === 'suspended') {
          this.sound.ctx.resume();
        }
        try {
          const buffer = this.sound.ctx.createBuffer(1, 1, 22050);
          const source = this.sound.ctx.createBufferSource();
          source.buffer = buffer;
          source.connect(this.sound.ctx.destination);
          source.start(0);
        } catch (e) {}
      }
      document.removeEventListener('touchstart', unlock);
      document.removeEventListener('touchend', unlock);
      document.removeEventListener('pointerdown', unlock);
    };

    document.addEventListener('touchstart', unlock, { passive: true });
    document.addEventListener('touchend', unlock, { passive: true });
    document.addEventListener('pointerdown', unlock, { passive: true });

    // Ekran Kapanmasını Önle (Wake Lock API)
    if ('wakeLock' in navigator) {
      try {
        navigator.wakeLock.request('screen').catch(() => {});
      } catch (e) {}
    }
  }

  toggleFullscreen() {
    if (this.fullscreenBtn) {
      this.fullscreenBtn.blur(); // Tıklandığı an tarayıcı tooltip / uyarı baloncuğunu hemen yok eder
    }

    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      const el = document.documentElement;
      if (el.requestFullscreen) {
        el.requestFullscreen().catch(() => {});
      } else if (el.webkitRequestFullscreen) {
        el.webkitRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      }
    }
  }

  // Tam Ekran ve Küçültme İkonu / Buton Güncellemesi
  updateFullscreenUI() {
    const isFs = !!(document.fullscreenElement || document.webkitFullscreenElement);
    if (this.fullscreenIconExpand && this.fullscreenIconCompress) {
      this.fullscreenIconExpand.classList.toggle('hidden', isFs);
      this.fullscreenIconCompress.classList.toggle('hidden', !isFs);
    }
    if (this.fullscreenBtn) {
      this.fullscreenBtn.title = isFs ? 'Küçült / Çık' : 'Tam Ekran';
      this.fullscreenBtn.blur(); // Odaklamayı kaldırıp uyarıyı yok eder
    }
  }

  openPhoneQrModal() {
    if (!this.phoneQrModal) return;
    this.phoneQrModal.classList.remove('hidden');

    let targetUrl = `http://192.168.1.147:3000`;
    if (window.location.hostname && window.location.hostname !== 'localhost' && window.location.hostname !== '127.0.0.1') {
      targetUrl = window.location.href;
    }

    // Sunucudan güncel yerel IP bilgisini al
    fetch('/api/info')
      .then(res => res.json())
      .then(data => {
        if (data && data.mobileUrl) {
          targetUrl = data.mobileUrl;
          this.updateQrDisplay(targetUrl);
        }
      })
      .catch(() => {
        this.updateQrDisplay(targetUrl);
      });

    this.updateQrDisplay(targetUrl);
  }

  updateQrDisplay(url) {
    if (this.mobileNetworkInput) {
      this.mobileNetworkInput.value = url;
    }

    if (this.qrCodeCanvas) {
      const ctx = this.qrCodeCanvas.getContext('2d');
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.clearRect(0, 0, 180, 180);
        ctx.drawImage(img, 0, 0, 180, 180);
      };
      img.onerror = () => {
        // Çevrimdışı görsel yedek
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 180, 180);
        ctx.fillStyle = '#0f0a17';
        ctx.font = 'bold 14px Outfit, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Tarayıcıya Yazın:', 90, 80);
        ctx.font = '12px monospace';
        ctx.fillText(url, 90, 105);
      };
      img.src = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(url)}`;
    }
  }
}

// Oyunu Sayfa Yüklendiğinde Başlat
document.addEventListener('DOMContentLoaded', () => {
  window.hotPotatoApp = new HotPotatoGame();
});
