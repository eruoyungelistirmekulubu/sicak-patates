/**
 * ============================================================
 * 🎮 100 ADET OYUN TEMALI SICAK PATATES SORU VERİTABANI
 * ============================================================
 */

const QUESTIONS_DATA = [
  // ------------------------------------------------------------
  // Kategori 1: Kişisel Zevkler & Favoriler (1-25)
  // ------------------------------------------------------------
  { id: 1, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Gelmiş geçmiş en iyi oyun karakteri kim?" },
  { id: 2, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Oynamaktan asla bıkmadığın o tek oyun?" },
  { id: 3, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Hikayesinin sonu seni en çok üzen oyun hangisiydi?" },
  { id: 4, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Bir oyundaki en havalı bölüm sonu canavarı (Boss) kimdi?" },
  { id: 5, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Açıp müziklerini Spotify’da dinlediğin bir oyun?" },
  { id: 6, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Bir oyun dünyasında yaşamak zorunda kalsan hangisini seçerdin?" },
  { id: 7, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "En sevdiğin açık dünya oyunu hangisi?" },
  { id: 8, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Sana göre tüm zamanların en iyi oyun serisi?" },
  { id: 9, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Çocukluğunun unutulmaz oyunu hangisiydi?" },
  { id: 10, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Oynadığın en iyi bağımsız (indie) oyun neydi?" },
  { id: 11, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "En beğendiğin hikayeli tek kişilik (singleplayer) oyun?" },
  { id: 12, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Grafikleriyle seni ilk gördüğünde büyüleyen oyun hangisiydi?" },
  { id: 13, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Favori FPS silahın (herhangi bir oyundan)?" },
  { id: 14, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Bir oyunda gördüğün en iyi ana düşman (antagonist) kimdi?" },
  { id: 15, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Co-op oynaması en keyifli oyun hangisi?" },
  { id: 16, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "En sevdiğin oyun yapım stüdyosu hangisi?" },
  { id: 17, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Oynarken seni en çok korkutan oyun neydi?" },
  { id: 18, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Hangi oyunun devamı çıksa dünyayı unutursun?" },
  { id: 19, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Bir oyundaki en sevdiğin ses efekti nedir?" },
  { id: 20, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Hangi oyunun ana karakteriyle gerçek hayatta kanka olmak isterdin?" },
  { id: 21, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "En sevdiğin RPG/RYO oyunu hangisi?" },
  { id: 22, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Şimdiye kadar gördüğün en havalı oyun introsu/açılışı?" },
  { id: 23, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Hayatta kalma (survival) türünde favori oyunun?" },
  { id: 24, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Bir oyunda bindiğin en havalı araç veya binek hayvan?" },
  { id: 25, category: "favoriler", categoryTitle: "🌟 Kişisel Zevkler & Favoriler", text: "Hangi oyunun sinema filmi ya da dizisi yapılsın isterdin?" },

  // ------------------------------------------------------------
  // Kategori 2: İtiraflar, Zor Anlar & Kötü Deneyimler (26-50)
  // ------------------------------------------------------------
  { id: 26, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Hayatında oynadığın en berbat oyun hangisiydi?" },
  { id: 27, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Steam indiriminde alıp yüzüne bile bakmadığın bir oyun söyle!" },
  { id: 28, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Hile açtığın ilk oyun hangisiydi?" },
  { id: 29, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyunda klavye/mouse kırma veya monitöre vurma noktasına geldiğin an?" },
  { id: 30, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyuna gömüldüğün için kaçırdığın en önemli gerçek hayat olayı?" },
  { id: 31, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Kütüphanende olup da 'Ben bunu niye aldım' dediğin oyun?" },
  { id: 32, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyunda saatlerce takılıp geçemediğin o lanet bölüm hangisiydi?" },
  { id: 33, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Karşılaştığın en komik ya da sinir bozucu oyun bug'ı?" },
  { id: 34, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Herkesin bayıldığı ama senin katlanamadığın o popüler oyun?" },
  { id: 35, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyunda yaptığın en haince/toxic hareket neydi?" },
  { id: 36, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "En son hangi oyunda hile veya bug kullandın?" },
  { id: 37, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Rekabetçi bir maçta takım arkadaşına ettiğin en ağır laf neydi?" },
  { id: 38, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyunda aldığın en gereksiz oyun içi kozmetik/skin?" },
  { id: 39, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Parasına asla değmediğini düşündüğün oyun hangisi?" },
  { id: 40, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Sabahlamak için söz verip oyunda uyuya kaldığın oldu mu?" },
  { id: 41, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Hikayesini zerre anlamadan sadece bitirmek için oynadığın bir oyun?" },
  { id: 42, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Arkadaş ortamında 'ben çok iyiyim' deyip rezil olduğun oyun?" },
  { id: 43, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyundaki en sinir bozucu yan görev türü nedir?" },
  { id: 44, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Korkup yarıda bıraktığın bir korku oyunu var mı?" },
  { id: 45, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Oynarken kendini en çok enayi gibi hissettiğin oyun içi satın alım?" },
  { id: 46, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Çok büyük beklentiyle çıkıp seni hayal kırıklığına uğratan oyun?" },
  { id: 47, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyunda sırf intikam almak için dakikalarca pusuda yattığın oldu mu?" },
  { id: 48, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Hangi oyunda en çok 'rage quit' attın?" },
  { id: 49, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Oynarken utandığın ama gizli gizli oynamaya devam ettiğin bir oyun?" },
  { id: 50, category: "itiraflar", categoryTitle: "💀 İtiraflar & Zor Anlar", text: "Bir oyundaki en saçma ölüm şeklin neydi?" },

  // ------------------------------------------------------------
  // Kategori 3: Seri Sayma & Hızlı Hafıza (3-5 Saniye Kuralı) (51-75)
  // ------------------------------------------------------------
  { id: 51, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 farklı oyun motoru say!" },
  { id: 52, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İsmi 'A' ile başlayan 3 oyun karakteri say!" },
  { id: 53, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 tane hayatta kalma oyunu söyle!" },
  { id: 54, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "Rockstar Games'in yaptığı 3 farklı oyun adı say!" },
  { id: 55, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 tane korku oyunu söyle!" },
  { id: 56, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İsmi 'S' ile başlayan 3 oyun stüdyosu say!" },
  { id: 57, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 tane retro (piksel/eski) oyun say!" },
  { id: 58, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "FPS türünde 3 popüler oyun söyle!" },
  { id: 59, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede içinde 'bıçak' veya 'kılıç' olan 3 oyun say!" },
  { id: 60, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İsmi bir renkle başlayan veya renk içeren 2 oyun söyle!" },
  { id: 61, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede PlayStation'a özel çıkmış 3 oyun say!" },
  { id: 62, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İçinde zombi olan 3 farklı oyun adı say!" },
  { id: 63, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 tane yarış oyunu söyle!" },
  { id: 64, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İsmi tek kelimeden oluşan 3 oyun say!" },
  { id: 65, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 farklı battle royale oyunu say!" },
  { id: 66, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "Bir oyun yapımında çalışan 3 farklı departman/rol say!" },
  { id: 67, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede uzayda geçen 3 farklı oyun adı söyle!" },
  { id: 68, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "Adında 'Kart', 'War' veya 'Craft' geçen 3 oyun say!" },
  { id: 69, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede Nintendo'nun yaptığı 3 oyun say!" },
  { id: 70, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "Bir bilgisayar kasasındaki 3 temel donanım parçasını say!" },
  { id: 71, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede açık dünya türünde 3 oyun say!" },
  { id: 72, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İsmi 'M' harfiyle başlayan 3 oyun karakteri say!" },
  { id: 73, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 tane sıra tabanlı (turn-based) strateji oyunu say!" },
  { id: 74, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "İçinde büyü/büyücü olan 3 farklı oyun adı say!" },
  { id: 75, category: "serisayma", categoryTitle: "⚡ 3-5 Saniye Kuralı", text: "3 saniyede 3 farklı spor oyunu say!" },

  // ------------------------------------------------------------
  // Kategori 4: Oyun İkilemleri, Mekanikler & Geliştirici Soruları (76-100)
  // ------------------------------------------------------------
  { id: 76, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Unity mi, Unreal Engine mi, Godot mu? (Tek kelime!)" },
  { id: 77, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Klavye-Mouse mu, Gamepad/Kol mu?" },
  { id: 78, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Piksel grafik mi, fotogerçekçi grafik mi?" },
  { id: 79, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Sonsuza kadar sadece tek kişilik oyunlar mı, sadece rekabetçi online oyunlar mı?" },
  { id: 80, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Bir oyun mekaniği gerçek hayatta sana verilseydi neyi seçerdin? (Double jump, save alma, envanter vb.)" },
  { id: 81, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "30 FPS akıcı 4K mı, 120 FPS 1080p mi?" },
  { id: 82, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Muazzam bir hikaye ama kötü oynanış mı, sıfır hikaye ama mükemmel oynanış mı?" },
  { id: 83, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Tamamen açık dünya mı, çizgisel ve dopdolu bir bölüm tasarımı mı?" },
  { id: 84, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Türkçe dublaj mı, Türkçe altyazı mı?" },
  { id: 85, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Çok zor souls-like bir oyun mu, kafa dağıtmalık kolay bir oyun mu?" },
  { id: 86, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Bir oyun yapacak olsan kamerası TPS (üçüncü şahıs) mi olurdu FPS mi?" },
  { id: 87, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Pay-to-win bir oyunda zengin olmak mı, yetenek tabanlı oyunda ortalama kalmak mı?" },
  { id: 88, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Sıfırdan bir oyun yapacak olsan ilk hangi türü denersin?" },
  { id: 89, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Bir oyunda en çok nefret ettiğin mekanik nedir? (Dayanıklılık barı, eşya kırılması, ağırlık sınırı vb.)" },
  { id: 90, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Oyunlarda stealth (gizlilik) mi, yoksa bam güm dalmak mı?" },
  { id: 91, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Erken erişim (Early Access) oyun almak mantıklı mı, tuzak mı?" },
  { id: 92, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Kodlama mı, 3D/2D modelleme ve animasyon mu, yoksa oyun tasarımı mı?" },
  { id: 93, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "VR gözlükler oyun dünyasının geleceği mi, yoksa geçici bir heves mi?" },
  { id: 94, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Bir oyunda boss dövüşü olmalı mı, yoksa hikaye odaklı mı bitmeli?" },
  { id: 95, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Sonsuza kadar sadece tek bir oyun yapımcısının oyunlarını oynayacak olsan kimi seçerdin?" },
  { id: 96, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Bir oyunda en sevdiğin kamera açısı hangisi? (İzometrik, TPS, FPS, 2D Side-scroller)" },
  { id: 97, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Mikro ödemeler ve loot box'lar tamamen yasaklanmalı mı?" },
  { id: 98, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Yapay zekanın oyun sektöründe insan geliştiricilerin yerini alacağını düşünüyor musun?" },
  { id: 99, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Bir oyunu bitirdikten sonra başarımları (achievements) kasmak için tekrar oynar mısın?" },
  { id: 100, category: "ikilemler", categoryTitle: "⚖️ Oyun İkilemleri & Geliştirici", text: "Kendi oyun stüdyonu kursan koyacağın ilk kural ne olurdu?" }
];

// Dışa aktarma ve global erişim
if (typeof module !== 'undefined' && module.exports) {
  module.exports = QUESTIONS_DATA;
}
