# 🔥 Sıcak Patates (Hot Potato) + 100 Oyun Sorusu

Tamamen modern HTML5, CSS3 ve JavaScript (Vanilla) ile geliştirilmiş, harici bağımlılık gerektirmeyen, yüksek görsellik, dinamik ses efektleri ve **100 adet oyun temalı soru/görev** içeren Sıcak Patates parti oyunu!

---

## 🎯 100 Oyun Sorusu Modu (Cevapla & Pasla!)

Patates elinizdeyken ekranda anlık soru belirir. Soruyu sesli olarak hızlıca cevaplayıp (özellikle 3-5 saniye kuralı sorularında) patates patlamadan önce diğer oyuncuya paslamalısınız!

### Soru Kategorileri:
1. **🌟 Kişisel Zevkler & Favoriler (1-25):** Gelmiş geçmiş en iyi karakterler, müzikler, dünyalar ve unutulmaz anlar.
2. **💀 İtiraflar, Zor Anlar & Kötü Deneyimler (26-50):** Rage quit anları, hile itirafları, monitör kırma raddeleri ve pişmanlıklar.
3. **⚡ Seri Sayma & Hızlı Hafıza / 3-5 Saniye Kuralı (51-75):** 3 saniyede 3 motor, 3 PlayStation oyunu veya 'A' harfli 3 karakter sayma meydan okumaları.
4. **⚖️ Oyun İkilemleri, Mekanikler & Geliştirici Soruları (76-100):** Unity mi Unreal mı, 30 FPS 4K mı 120 FPS 1080p mi, dublaj mı altyazı mı ikilemleri.
5. **🎲 Karışık Mod:** Tüm 100 sorunun rastgele harmanlandığı tam parti modu.

> Üst menüdeki **❓ (Soru Listesi)** butonuna tıklayarak tüm 100 soruyu kategori filtreleriyle anında inceleyebilirsiniz.

---

## 🎮 Oyun Modları

### 1. 🔄 Çember Eleme Modu (Arcade - 2 ila 8 Oyuncu)
- Oyuncular tek ekranda çember halinde dizilir. İsimler ve karakter avatarları kişiselleştirilebilir.
- **Bot Desteği:** İster arkadaşlarınla yan yana, istersen yapay zeka botlara karşı oyna!
- **Gizli Sayaç:** Patatesin patlama zamanı tamamen gizlidir. Süre azaldıkça patates terlemeye başlar, alev alır ve ses çılgınca hızlanır.
- **Boşluk (Space)** tuşuna basarak veya ekrandaki **PASLA!** butonuna dokunarak patatesi hızla yanındakine fırlat!
- Patates elinde patlayan oyuncu elenir ve eğlenceli bir parti görevi (ceza) kartı açılır.
- En son hayatta kalan oyuncu **Patates Şampiyonu** olur!

### 2. 📱 Cihazı Pasla (Fiziksel Parti Modu - 30+ Kişiye Kadar Destek!)
- Sınıflar, doğum günleri, geniş aile ve kalabalık arkadaş grupları (2 ila 30+ kişi) için özel olarak tasarlandı.
- **👥 Grup Büyüklüğü & Tur Süresi Seçenekleri:**
  - ⚡ 2-5 Kişi (25-45s)
  - ⏱️ 5-12 Kişi (45-85s)
  - ⏳ 12-20 Kişi (1.5 - 2.5 dk)
  - 🎉 **30 Kişilik Dev Parti (2.5 - 4.5 dakika):** Patatesin 30 kişilik devasa bir grupta herkesi dolaşabilmesi için optimize edilmiş gizli süre!
- **🔢 Canlı Pas / Kişi Sayacı:** Cihaz elden ele geçerken ekranda *"🔥 PATATESİ TUTAN: 17. Oyuncu"* şeklinde canlı takip gösterilir.
- **💥 Elenme Duyurusu:** Patlama anında *"💥 24. OYUNCUDA PATLADI!"* başlığıyla patatesin tam kimin elinde kaldığı tüm odaya duyurulur ve eğlenceli ceza görevi verilir!

---

## ✨ Özellikler ve Tasarım Detayları

- **Web Audio API Entegre Ses Sentezleyicisi:** Harici ses dosyası indirme veya internet bağlantısı gerektirmez. Tık sesleri, hava fırlatma sesi (whoosh), kızarma cızırtısı, devasa patlama (boom) ve zafer melodisi anında tarayıcı içinde sentezlenir.
- **Canlı Partikül Efektleri:** Arka planda uçuşan közler, alev kıvılcımları ve zafer anında patlayan renkli konfetiler.
- **Dinamik SVG Patates Karakteri:** Sıcaklık arttıkça sakin -> terleyen -> alev alan -> patlayan aşamalı sevimli yüz ifadeleri ve animasyonlar.
- **100 Soru Kütüphanesi Modalı:** Tüm soruları kategoriye göre filtreleme imkanı.
- **Tam Mobil & Masaüstü Uyumu (Responsive):** Telefondan, tabletten veya bilgisayardan rahatça oynanabilir.

---

## 📱 Telefon ve Diğer Cihazlarda (Tablet, TV, Laptop) Nasıl Oynanır?

Oyun; **iPhone (iOS Safari), Android (Chrome, Samsung Internet), iPad, Tablet ve Masaüstü** dahil tüm cihazlarda kusursuz çalışacak şekilde optimize edilmiştir.

### 1. Yöntem: Aynı Wi-Fi Üzerinden Telefonda Açma (Önerilen)
1. Bilgisayarınızda `oyunu_baslat.bat` dosyasını çift tıklayın (veya terminalde `node server.js` çalıştırın).
2. Oyun ekranının sağ üstündeki **📱 (Telefonda Oyna)** butonuna tıklayın.
3. Telefonunuzun kamerasını ekrandaki **QR Koda** tutun veya telefon tarayıcınıza şu adresi yazın:
   👉 **`http://192.168.1.147:3000`**
4. Anında telefonunuzda oyun açılacaktır!

### 2. Yöntem: Doğrudan Dosya Olarak Açma
- Projedeki `index.html` dosyasını telefonunuza veya tabletinize gönderip herhangi bir tarayıcıda doğrudan çift tıklayarak internetsiz de açabilirsiniz.

### 3. Yöntem: Telefonda Uygulama Olarak Kaydetme (PWA)
- Safari veya Chrome'da açtıktan sonra **"Ana Ekrana Ekle (Add to Home Screen)"** butonuna basarak telefona tam ekran bir mobil uygulama gibi yükleyebilirsiniz.

---

## 📳 Mobil Deneyim İçin Özel Eklenenler:
- **Titreşimli Geri Bildirim (Haptic Feedback):** Pas verirken ve patlama anında telefon gerçekçi şekilde titrer.
- **iOS Safari Ses Kilidi Açıcı:** Dokunduğunuz anda ses efektleri aktifleşir.
- **Ekran Kapanmasını Önleme (Wake Lock):** Cihazı elden ele geçirirken telefonun ekranı kararmaz veya kilitlenmez.
- **Tam Ekran Desteği (⛶ Butonu):** Tarayıcı çubuklarını gizleyerek tam ekran oyun deneyimi sunar.
- **Dinamik Çentik & Güvenli Alan Desteği:** iPhone çentikleri veya Android gezinme çubuklarıyla çakışmaz.
